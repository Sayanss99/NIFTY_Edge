"""Analytics API routes — performance, strike patterns, insights."""

from datetime import datetime, timedelta
from collections import defaultdict
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from database import get_db
from models import Trade, TradeStatus, User, MarketSnapshot
from auth import get_current_user
from config import LOT_SIZE

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/performance")
def performance_overview(
    months: int = Query(0, description="Filter last N months, 0=all"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Performance overview — P&L curve, expiry bars, monthly heatmap."""
    query = db.query(Trade).filter(
        Trade.user_id == user.id,
        Trade.status == TradeStatus.CLOSED.value,
    )
    if months > 0:
        cutoff = datetime.utcnow() - timedelta(days=months * 30)
        query = query.filter(Trade.exit_date >= cutoff)

    trades = query.order_by(Trade.exit_date.asc()).all()

    if not trades:
        return {
            "summary": {"total_pnl": 0, "win_rate": 0, "avg_per_expiry": 0, "max_drawdown": 0, "trade_count": 0},
            "cumulative_pnl": [],
            "expiry_pnl": [],
            "monthly_pnl": [],
        }

    # Summary metrics
    pnls = [t.realized_pnl or 0 for t in trades]
    wins = sum(1 for p in pnls if p > 0)

    # P&L by expiry
    expiry_map = defaultdict(float)
    for t in trades:
        expiry_map[t.expiry_date] += t.realized_pnl or 0

    avg_per_expiry = sum(expiry_map.values()) / len(expiry_map) if expiry_map else 0

    # Max drawdown from cumulative P&L
    cumulative = []
    running = 0
    peak = 0
    max_dd = 0
    for t in trades:
        running += t.realized_pnl or 0
        peak = max(peak, running)
        dd = peak - running
        max_dd = max(max_dd, dd)
        cumulative.append({
            "date": t.exit_date.strftime("%Y-%m-%d") if t.exit_date else None,
            "pnl": round(running, 2),
            "trade_type": t.trade_type,
            "strike": t.strike,
        })

    # Expiry P&L bars
    expiry_pnl = [
        {"expiry": exp, "pnl": round(pnl, 2)}
        for exp, pnl in sorted(expiry_map.items())
    ]

    # Monthly P&L heatmap
    monthly_map = defaultdict(float)
    for t in trades:
        if t.exit_date:
            key = t.exit_date.strftime("%Y-%m")
            monthly_map[key] += t.realized_pnl or 0

    monthly_pnl = [
        {"month": m, "pnl": round(p, 2)}
        for m, p in sorted(monthly_map.items())
    ]

    return {
        "summary": {
            "total_pnl": round(sum(pnls), 2),
            "win_rate": round(wins / len(pnls) * 100, 1) if pnls else 0,
            "avg_per_expiry": round(avg_per_expiry, 2),
            "max_drawdown": round(max_dd, 2),
            "trade_count": len(trades),
        },
        "cumulative_pnl": cumulative,
        "expiry_pnl": expiry_pnl,
        "monthly_pnl": monthly_pnl,
    }


@router.get("/strike-patterns")
def strike_patterns(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Strike distance analysis and VIX regime breakdown."""
    trades = db.query(Trade).filter(
        Trade.user_id == user.id,
        Trade.status == TradeStatus.CLOSED.value,
    ).order_by(Trade.exit_date.asc()).all()

    if not trades:
        return {"ce_distances": [], "pe_distances": [], "vix_regime": [], "insights": []}

    # We need snapshot data to know spot at entry time for distance calc.
    # Use entry_delta as a proxy for OTM-ness, but also compute strike distance
    # from closest snapshot at trade entry time.
    ce_data = []
    pe_data = []

    for t in trades:
        pnl = t.realized_pnl or 0
        # Get spot near entry time
        snap = None
        if t.entry_date:
            snap = db.query(MarketSnapshot).filter(
                MarketSnapshot.timestamp <= t.entry_date
            ).order_by(MarketSnapshot.timestamp.desc()).first()

        spot_at_entry = snap.nifty_spot if snap else 0
        distance = abs(t.strike - spot_at_entry) if spot_at_entry > 0 else 0

        entry = {
            "strike": t.strike,
            "distance": round(distance),
            "distance_pct": round(distance / spot_at_entry * 100, 1) if spot_at_entry else 0,
            "pnl": round(pnl, 2),
            "win": pnl > 0,
            "entry_iv": t.entry_iv,
            "entry_delta": abs(t.entry_delta) if t.entry_delta else 0,
            "quantity": t.quantity,
            "expiry": t.expiry_date,
        }

        if "CE" in t.trade_type:
            ce_data.append(entry)
        else:
            pe_data.append(entry)

    # VIX regime analysis (from entry IV as proxy — or entry snapshot VIX)
    vix_buckets = {"low": {"label": "VIX < 15", "wins": 0, "total": 0, "pnl": 0},
                   "mid": {"label": "15 <= VIX < 25", "wins": 0, "total": 0, "pnl": 0},
                   "high": {"label": "VIX >= 25", "wins": 0, "total": 0, "pnl": 0}}

    for t in trades:
        snap = None
        if t.entry_date:
            snap = db.query(MarketSnapshot).filter(
                MarketSnapshot.timestamp <= t.entry_date
            ).order_by(MarketSnapshot.timestamp.desc()).first()
        vix_at_entry = snap.india_vix if snap else 0

        pnl = t.realized_pnl or 0
        if vix_at_entry < 15:
            bucket = vix_buckets["low"]
        elif vix_at_entry < 25:
            bucket = vix_buckets["mid"]
        else:
            bucket = vix_buckets["high"]

        bucket["total"] += 1
        bucket["pnl"] += pnl
        if pnl > 0:
            bucket["wins"] += 1

    vix_regime = []
    for key in ["low", "mid", "high"]:
        b = vix_buckets[key]
        vix_regime.append({
            "label": b["label"],
            "total": b["total"],
            "wins": b["wins"],
            "win_rate": round(b["wins"] / b["total"] * 100, 1) if b["total"] else 0,
            "pnl": round(b["pnl"], 2),
        })

    # Auto-generated insights
    insights = _generate_insights(ce_data, pe_data, vix_regime)

    return {
        "ce_distances": ce_data,
        "pe_distances": pe_data,
        "vix_regime": vix_regime,
        "insights": insights,
    }


def _generate_insights(ce_data, pe_data, vix_regime):
    """Generate auto-insights from trade patterns."""
    insights = []

    # CE distance sweet spot
    if ce_data:
        winning_ce = [d for d in ce_data if d["win"]]
        if winning_ce:
            avg_win_dist = sum(d["distance"] for d in winning_ce) / len(winning_ce)
            total_ce_wr = len(winning_ce) / len(ce_data) * 100
            insights.append(
                f"CE sells: {total_ce_wr:.0f}% win rate across {len(ce_data)} trades. "
                f"Winning CEs avg {avg_win_dist:.0f}pts OTM."
            )

    # PE distance sweet spot
    if pe_data:
        winning_pe = [d for d in pe_data if d["win"]]
        if winning_pe:
            avg_win_dist = sum(d["distance"] for d in winning_pe) / len(winning_pe)
            total_pe_wr = len(winning_pe) / len(pe_data) * 100
            insights.append(
                f"PE sells: {total_pe_wr:.0f}% win rate across {len(pe_data)} trades. "
                f"Winning PEs avg {avg_win_dist:.0f}pts OTM."
            )

    # VIX regime insight
    for regime in vix_regime:
        if regime["total"] >= 3:
            if regime["win_rate"] < 50:
                insights.append(
                    f"Win rate drops to {regime['win_rate']}% when {regime['label']} "
                    f"({regime['total']} trades) — consider reducing size."
                )
            elif regime["win_rate"] >= 80:
                insights.append(
                    f"Strong {regime['win_rate']}% win rate when {regime['label']} "
                    f"({regime['total']} trades)."
                )

    # Distance threshold insight
    for label, data in [("CE", ce_data), ("PE", pe_data)]:
        far_otm = [d for d in data if d["distance"] > 800]
        if len(far_otm) >= 2:
            far_wins = sum(1 for d in far_otm if d["win"])
            far_wr = far_wins / len(far_otm) * 100
            if far_wr >= 80:
                insights.append(
                    f"You've won {far_wr:.0f}% selling {label} >800pts OTM ({len(far_otm)} trades)."
                )

    return insights if insights else ["Not enough trade history for pattern insights yet."]
