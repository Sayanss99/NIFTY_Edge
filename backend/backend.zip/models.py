"""SQLAlchemy ORM models for NiftyEdge."""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, Float, String, DateTime, Date, Boolean,
    ForeignKey, JSON, Text, Enum as SQLEnum
)
from sqlalchemy.orm import relationship
from database import Base
import enum


# ── Enums ────────────────────────────────────────────────────────────────────

class TradeType(str, enum.Enum):
    CE_SELL = "CE_SELL"
    PE_SELL = "PE_SELL"
    CE_BUY = "CE_BUY"
    PE_BUY = "PE_BUY"


class TradeStatus(str, enum.Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"


class AlertStatus(str, enum.Enum):
    ARMED = "ARMED"
    TRIGGERED = "TRIGGERED"
    PAUSED = "PAUSED"


# ── User ─────────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    settings = Column(JSON, default=dict)

    trades = relationship("Trade", back_populates="user")
    alerts = relationship("AlertRule", back_populates="user")


# ── Trade ────────────────────────────────────────────────────────────────────

class Trade(Base):
    __tablename__ = "trades"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    trade_type = Column(String, nullable=False)  # CE_SELL, PE_SELL, CE_BUY, PE_BUY
    strike = Column(Integer, nullable=False)
    expiry_date = Column(String, nullable=False)  # DD-Mon-YYYY format
    entry_premium = Column(Float, nullable=False)
    entry_iv = Column(Float, default=0.0)
    entry_delta = Column(Float, default=0.0)
    entry_date = Column(DateTime, default=datetime.utcnow)
    quantity = Column(Integer, nullable=False, default=1)  # in lots
    exit_price = Column(Float, nullable=True)
    exit_date = Column(DateTime, nullable=True)
    status = Column(String, default=TradeStatus.OPEN.value)
    parent_trade_id = Column(Integer, ForeignKey("trades.id"), nullable=True)
    realized_pnl = Column(Float, nullable=True)

    user = relationship("User", back_populates="trades")
    hedges = relationship("Trade", foreign_keys=[parent_trade_id])


# ── Market Snapshot (shared, written by data engine) ─────────────────────────

class MarketSnapshot(Base):
    __tablename__ = "market_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    nifty_spot = Column(Float, nullable=False)
    nifty_change = Column(Float, nullable=True)
    nifty_change_pct = Column(Float, nullable=True)
    india_vix = Column(Float, nullable=True)
    vix_change = Column(Float, nullable=True)
    vix_change_pct = Column(Float, nullable=True)
    calculated_range_top = Column(Float, nullable=True)
    calculated_range_bottom = Column(Float, nullable=True)
    vix_range_top = Column(Float, nullable=True)
    vix_range_bottom = Column(Float, nullable=True)
    expected_move = Column(Float, nullable=True)
    days_to_expiry = Column(Integer, nullable=True)
    tendency = Column(String, nullable=True)
    expiry_date = Column(String, nullable=True)
    # 25-Delta Risk Reversal fields
    rr_ce_strike = Column(Integer, nullable=True)
    rr_ce_iv = Column(Float, nullable=True)
    rr_pe_strike = Column(Integer, nullable=True)
    rr_pe_iv = Column(Float, nullable=True)
    rr_value = Column(Float, nullable=True)
    rr_verdict = Column(String, nullable=True)
    # Max Pain & Directional Signal
    max_pain = Column(Float, nullable=True)
    directional_direction = Column(String, nullable=True)  # BULLISH, BEARISH, NEUTRAL
    directional_score = Column(Float, nullable=True)
    directional_factors_agree = Column(Integer, nullable=True)


# ── Strike Data (per strike per snapshot) ────────────────────────────────────

class StrikeData(Base):
    __tablename__ = "strike_data"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    strike = Column(Integer, nullable=False, index=True)
    expiry_date = Column(String, nullable=False)
    option_type = Column(String, nullable=False)  # CE or PE
    ltp = Column(Float, nullable=True)
    iv = Column(Float, nullable=True)
    delta = Column(Float, nullable=True)
    gamma = Column(Float, nullable=True)
    theta = Column(Float, nullable=True)
    vega = Column(Float, nullable=True)
    oi = Column(Float, nullable=True)
    volume = Column(Float, nullable=True)


# ── Support/Resistance Levels ────────────────────────────────────────────────

class SRLevel(Base):
    __tablename__ = "sr_levels"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    expiry_date = Column(String, nullable=True)
    source = Column(String, nullable=False)  # OI_FIB, PIVOT_OI
    level_type = Column(String, nullable=False)  # SUPPORT, RESISTANCE
    strike = Column(Integer, nullable=False)
    oi = Column(Float, nullable=True)
    label = Column(String, nullable=True)  # e.g. "OI+Fib ✓ (fib 23200)"


# ── Alert Rule ───────────────────────────────────────────────────────────────

class AlertRule(Base):
    __tablename__ = "alert_rules"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    metric = Column(String, nullable=False)
    # Metrics: nifty_spot, india_vix, ce_risk, pe_risk,
    #          position_delta, position_iv, position_premium, range_breach
    condition = Column(String, nullable=False)  # gt, lt, crosses_above, crosses_below
    threshold = Column(Float, nullable=False)
    trade_id = Column(Integer, ForeignKey("trades.id"), nullable=True)  # for position-specific alerts
    notification_method = Column(String, default="in_app")
    status = Column(String, default=AlertStatus.ARMED.value)
    cooldown_minutes = Column(Integer, default=15)
    last_triggered_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="alerts")
    trade = relationship("Trade", foreign_keys=[trade_id])
    logs = relationship("AlertLog", back_populates="rule")


class AlertLog(Base):
    __tablename__ = "alert_logs"

    id = Column(Integer, primary_key=True, index=True)
    alert_rule_id = Column(Integer, ForeignKey("alert_rules.id"), nullable=False)
    triggered_at = Column(DateTime, default=datetime.utcnow)
    triggered_value = Column(Float, nullable=True)
    message = Column(String, nullable=True)

    rule = relationship("AlertRule", back_populates="logs")
