"""Background data refresh scheduler — fetches market data periodically
and pushes updates via WebSocket.

Market hours: Weekdays 9:00-15:45 IST (excluding NSE holidays).
Outside these hours, no API calls are made — only a "market_closed" message is sent.
"""

import asyncio
import traceback
import numpy as np
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from database import SessionLocal
from models import MarketSnapshot, SRLevel, Trade, TradeStatus
from config import LOT_SIZE, FAST_REFRESH_SECONDS, SLOW_REFRESH_MULTIPLIER


def _py(val):
    """Convert numpy types to native Python for JSON serialization."""
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return float(val)
    return val

# IST = UTC+5:30
IST = timezone(timedelta(hours=5, minutes=30))

# Cross-cycle state for directional signal OI buildup tracking
_prev_oi_snapshot = None

# NSE holidays for 2026 (update yearly)
# Source: NSE circular — add dates as they are announced
NSE_HOLIDAYS_2026 = {
    "2026-01-26",  # Republic Day
    "2026-02-17",  # Mahashivratri (tentative)
    "2026-03-10",  # Holi
    "2026-03-30",  # Id-Ul-Fitr (tentative)
    "2026-04-02",  # Ram Navami
    "2026-04-03",  # Mahavir Jayanti
    "2026-04-14",  # Dr. Ambedkar Jayanti / Good Friday
    "2026-05-01",  # Maharashtra Day
    "2026-05-25",  # Buddha Purnima (tentative)
    "2026-06-06",  # Bakri Id (tentative)
    "2026-07-06",  # Muharram (tentative)
    "2026-08-15",  # Independence Day
    "2026-08-25",  # Ganesh Chaturthi (tentative)
    "2026-10-02",  # Mahatma Gandhi Jayanti
    "2026-10-20",  # Dussehra (tentative)
    "2026-10-21",  # Dussehra (tentative)
    "2026-11-09",  # Diwali (Laxmi Puja) (tentative)
    "2026-11-10",  # Diwali (Balipratipada) (tentative)
    "2026-11-30",  # Guru Nanak Jayanti (tentative)
    "2026-12-25",  # Christmas
}


def is_market_open() -> dict:
    """Check if NSE market is currently open.

    Returns dict with:
        open: bool
        reason: str (why closed, if closed)
        next_open: str (approximate next open time)
    """
    now_ist = datetime.now(IST)
    today_str = now_ist.strftime("%Y-%m-%d")
    weekday = now_ist.weekday()  # 0=Mon, 6=Sun
    current_time = now_ist.strftime("%H:%M")

    # Weekend
    if weekday >= 5:
        days_to_monday = 7 - weekday
        next_open = (now_ist + timedelta(days=days_to_monday)).replace(
            hour=9, minute=0, second=0
        )
        return {
            "open": False,
            "reason": "Weekend",
            "next_open": next_open.strftime("%a %d %b, 9:00 AM"),
        }

    # NSE holiday
    if today_str in NSE_HOLIDAYS_2026:
        next_day = now_ist + timedelta(days=1)
        while next_day.weekday() >= 5 or next_day.strftime("%Y-%m-%d") in NSE_HOLIDAYS_2026:
            next_day += timedelta(days=1)
        return {
            "open": False,
            "reason": "NSE Holiday",
            "next_open": next_day.strftime("%a %d %b, 9:00 AM"),
        }

    # Before market hours
    if current_time < "09:00":
        return {
            "open": False,
            "reason": "Pre-market",
            "next_open": "Today, 9:00 AM",
        }

    # After market hours
    if current_time > "15:45":
        next_day = now_ist + timedelta(days=1)
        while next_day.weekday() >= 5 or next_day.strftime("%Y-%m-%d") in NSE_HOLIDAYS_2026:
            next_day += timedelta(days=1)
        return {
            "open": False,
            "reason": "Market closed",
            "next_open": next_day.strftime("%a %d %b, 9:00 AM"),
        }

    # Market is open
    return {"open": True, "reason": "", "next_open": ""}


async def run_scheduler(ws_manager):
    """Main scheduler loop — runs in background."""
    cycle = 0
    last_market_status = None
    print("[Scheduler] Starting market data refresh loop...")

    # ── Seed fetch: if DB is empty, do one-time fetch regardless of market hours ──
    try:
        db = SessionLocal()
        try:
            has_data = db.query(MarketSnapshot).first() is not None
        finally:
            db.close()

        if not has_data:
            print("[Scheduler] No snapshot data in DB — running initial seed fetch...")
            db = SessionLocal()
            try:
                data = await asyncio.get_event_loop().run_in_executor(
                    None, _fetch_market_data, db, True  # slow_cycle=True to also fetch S/R
                )
                if data:
                    print("[Scheduler] Seed fetch complete — initial data stored")
                else:
                    print("[Scheduler] Seed fetch returned no data (NSE may be unreachable)")
            finally:
                db.close()
    except Exception as e:
        print(f"[Scheduler] Seed fetch error: {e}")

    while True:
        try:
            market_status = is_market_open()

            # If market is closed, broadcast status and skip data fetch
            if not market_status["open"]:
                if last_market_status is None or last_market_status.get("open", True):
                    # Status just changed to closed — broadcast once
                    print(f"[Scheduler] Market closed: {market_status['reason']}")

                    # Send last known snapshot + closed status
                    db = SessionLocal()
                    try:
                        snap = db.query(MarketSnapshot).order_by(
                            MarketSnapshot.timestamp.desc()
                        ).first()
                        snapshot_data = None
                        if snap:
                            snapshot_data = {
                                "nifty_spot": snap.nifty_spot,
                                "nifty_change": snap.nifty_change,
                                "nifty_change_pct": snap.nifty_change_pct,
                                "india_vix": snap.india_vix,
                                "vix_change": snap.vix_change,
                                "vix_change_pct": snap.vix_change_pct,
                                "calc_range_top": snap.calculated_range_top,
                                "calc_range_bottom": snap.calculated_range_bottom,
                                "vix_range_top": snap.vix_range_top,
                                "vix_range_bottom": snap.vix_range_bottom,
                                "expected_move": snap.expected_move,
                                "days_to_expiry": snap.days_to_expiry,
                                "tendency": snap.tendency,
                                "expiry_date": snap.expiry_date,
                                "timestamp": snap.timestamp.isoformat() if snap.timestamp else None,
                                "max_pain": snap.max_pain,
                                "directional_signal": {
                                    "direction": snap.directional_direction,
                                    "score": snap.directional_score,
                                    "factors_agree": snap.directional_factors_agree,
                                } if snap.directional_direction else None,
                                "risk_reversal": {
                                    "ce_strike": snap.rr_ce_strike,
                                    "ce_iv": snap.rr_ce_iv,
                                    "pe_strike": snap.rr_pe_strike,
                                    "pe_iv": snap.rr_pe_iv,
                                    "rr_value": snap.rr_value,
                                    "verdict": snap.rr_verdict,
                                },
                            }
                    finally:
                        db.close()

                    await ws_manager.broadcast({
                        "type": "market_status",
                        "data": {
                            "open": False,
                            "reason": market_status["reason"],
                            "next_open": market_status["next_open"],
                            "last_snapshot": snapshot_data,
                        },
                    })

                last_market_status = market_status
                # Sleep longer when market is closed (check every 30s)
                await asyncio.sleep(30)
                continue

            # Market is open — normal refresh cycle
            if last_market_status and not last_market_status.get("open", True):
                print("[Scheduler] Market opened — resuming live data refresh")
                await ws_manager.broadcast({
                    "type": "market_status",
                    "data": {"open": True, "reason": "", "next_open": ""},
                })

            last_market_status = market_status
            cycle += 1
            is_slow_cycle = (cycle % SLOW_REFRESH_MULTIPLIER == 0)

            db = SessionLocal()
            try:
                data = await asyncio.get_event_loop().run_in_executor(
                    None, _fetch_market_data, db, is_slow_cycle
                )

                if data:
                    await ws_manager.broadcast({
                        "type": "market_update",
                        "data": data["snapshot"],
                    })

                    if data.get("option_chain"):
                        await ws_manager.broadcast({
                            "type": "chain_update",
                            "data": data["option_chain"],
                        })

                    for user_id in ws_manager.connected_user_ids:
                        user_data = await asyncio.get_event_loop().run_in_executor(
                            None, _compute_user_positions, db, user_id, data
                        )
                        if user_data:
                            await ws_manager.send_to_user(user_id, {
                                "type": "positions_update",
                                "data": user_data,
                            })

                    if is_slow_cycle and data.get("sr_levels"):
                        await ws_manager.broadcast({
                            "type": "sr_update",
                            "data": data["sr_levels"],
                        })

                    if data.get("risk_reversal"):
                        await ws_manager.broadcast({
                            "type": "risk_reversal_update",
                            "data": data["risk_reversal"],
                        })

                    # ── Evaluate alert rules ───────────────────────────
                    try:
                        from alert_engine import evaluate_alerts
                        triggered = evaluate_alerts(
                            db,
                            snapshot=data["snapshot"],
                            chain_df=data.get("chain_df"),
                            risk_data=None,  # risk computed per-user above
                        )
                        for alert in triggered:
                            await ws_manager.send_to_user(alert["user_id"], {
                                "type": "alert_triggered",
                                "data": alert,
                            })
                        if triggered:
                            print(f"[Scheduler] {len(triggered)} alert(s) triggered")
                    except Exception as e:
                        print(f"[Scheduler] Alert eval error: {e}")

            finally:
                db.close()

        except Exception as e:
            print(f"[Scheduler] Error: {e}")
            traceback.print_exc()

        await asyncio.sleep(FAST_REFRESH_SECONDS)


def _fetch_market_data(db: Session, is_slow_cycle: bool) -> dict | None:
    """Fetch all market data (runs in thread pool)."""
    global _prev_oi_snapshot
    from market_data import (
        build_chain, fetch_vix, calculate_ranges, days_to_expiry,
        find_oi_sr_levels, fetch_fibonacci_levels, fetch_pivot_levels,
        merge_sr_levels, compute_pivot_oi_sr,
        compute_risk_reversal, compute_tendency,
        compute_directional_signal, snapshot_oi, compute_max_pain,
        select_trade_strike,
    )

    try:
        chain_df, expiries, spot = build_chain("NIFTY")
        if chain_df.empty:
            print("[Scheduler] Empty chain data")
            return None
    except Exception as e:
        print(f"[Scheduler] Chain fetch failed: {e}")
        return None

    expiry = expiries[0] if expiries else ""
    dte = days_to_expiry(expiry) if expiry else 0

    vix_data = fetch_vix()
    vix = vix_data["last"] if vix_data else 0
    vix_change = vix_data["change"] if vix_data else 0
    vix_change_pct = vix_data["pChange"] if vix_data else 0
    nifty_change = vix_data.get("nifty_change", 0) if vix_data else 0
    nifty_change_pct = vix_data.get("nifty_change_pct", 0) if vix_data else 0

    # Use default offset for snapshot; per-user offsets applied on frontend
    default_offset = 50  # default VIX offset %
    ranges = calculate_ranges(spot, vix, dte, vix_offset_pct=default_offset)
    rr = compute_risk_reversal(chain_df)
    tendency_data = compute_tendency(rr["rr_value"], vix, vix_change_pct)

    # 8-factor directional signal
    vix_data_full = vix_data if vix_data else None
    dir_signal = compute_directional_signal(chain_df, spot, vix_data_full, _prev_oi_snapshot)
    _prev_oi_snapshot = snapshot_oi(chain_df, spot)

    # Trade suggestion based on directional signal
    trade_suggestion = None
    if dir_signal["direction"] != "NEUTRAL":
        trade_suggestion = select_trade_strike(chain_df, spot, dir_signal["direction"], dte)

    snapshot = MarketSnapshot(
        nifty_spot=spot,
        nifty_change=nifty_change,
        nifty_change_pct=nifty_change_pct,
        india_vix=vix,
        vix_change=vix_change,
        vix_change_pct=vix_change_pct,
        calculated_range_top=ranges["calc_range_top"],
        calculated_range_bottom=ranges["calc_range_bottom"],
        vix_range_top=ranges["vix_range_top"],
        vix_range_bottom=ranges["vix_range_bottom"],
        expected_move=0,  # deprecated, range shown directly
        days_to_expiry=dte,
        tendency=tendency_data["label"],
        expiry_date=expiry,
        rr_ce_strike=rr.get("ce_strike"),
        rr_ce_iv=rr.get("ce_iv"),
        rr_pe_strike=rr.get("pe_strike"),
        rr_pe_iv=rr.get("pe_iv"),
        rr_value=rr.get("rr_value"),
        rr_verdict=rr.get("verdict"),
        max_pain=dir_signal.get("max_pain", 0),
        directional_direction=dir_signal.get("direction"),
        directional_score=dir_signal.get("score"),
        directional_factors_agree=dir_signal.get("factors_agree"),
    )
    db.add(snapshot)
    db.commit()

    now_ist = datetime.now(IST)
    snapshot_data = {
        "nifty_spot": spot,
        "nifty_change": nifty_change,
        "nifty_change_pct": nifty_change_pct,
        "india_vix": vix,
        "vix_change": vix_change,
        "vix_change_pct": vix_change_pct,
        "calc_range_top": ranges["calc_range_top"],
        "calc_range_bottom": ranges["calc_range_bottom"],
        "vix_range_top": ranges["vix_range_top"],
        "vix_range_bottom": ranges["vix_range_bottom"],
        "days_to_expiry": dte,
        "tendency": tendency_data["label"],
        "tendency_detail": tendency_data,
        "directional_signal": dir_signal,
        "trade_suggestion": trade_suggestion,
        "max_pain": dir_signal.get("max_pain", 0),
        "expiry_date": expiry,
        "expiries": expiries,
        "timestamp": now_ist.isoformat(),
    }

    result = {
        "snapshot": snapshot_data,
        "risk_reversal": rr,
        "chain_df": chain_df,
        "spot": spot,
        "expiry": expiry,
    }

    # Build option chain for frontend
    strikes = sorted(chain_df["Strike"].unique())
    chain_rows = []
    for strike in strikes:
        row_data = {"strike": _py(strike)}
        ce = chain_df[(chain_df["Strike"] == strike) & (chain_df["Type"] == "CE")]
        pe = chain_df[(chain_df["Strike"] == strike) & (chain_df["Type"] == "PE")]
        if not ce.empty:
            c = ce.iloc[0]
            row_data.update({
                "ce_ltp": _py(c["LTP"]), "ce_iv": _py(c["IV"]),
                "ce_delta": _py(c["delta"]), "ce_oi": _py(c["OI"]),
            })
        if not pe.empty:
            p = pe.iloc[0]
            row_data.update({
                "pe_ltp": _py(p["LTP"]), "pe_iv": _py(p["IV"]),
                "pe_delta": _py(p["delta"]), "pe_oi": _py(p["OI"]),
            })
        chain_rows.append(row_data)

    result["option_chain"] = {"rows": chain_rows, "spot": spot}

    # S/R levels on slow cycle
    if is_slow_cycle:
        try:
            oi_sr = find_oi_sr_levels(chain_df, spot)
            fib_levels = fetch_fibonacci_levels()
            pivot_data = fetch_pivot_levels()

            # Merge OI + Fibonacci with confluence prioritisation
            merged_supports, merged_resistances = merge_sr_levels(
                oi_sr["supports"], oi_sr["resistances"],
                fib_levels, spot,
            )

            # Pivot + OI ranked S/R
            pivot_supports, pivot_resistances = compute_pivot_oi_sr(
                chain_df, spot, pivot_data,
            )

            now = datetime.utcnow()
            for s in merged_supports:
                db.add(SRLevel(timestamp=now, expiry_date=expiry, source="OI_FIB",
                               level_type="SUPPORT", strike=s["strike"],
                               oi=s.get("oi"), label=s.get("source")))
            for r in merged_resistances:
                db.add(SRLevel(timestamp=now, expiry_date=expiry, source="OI_FIB",
                               level_type="RESISTANCE", strike=r["strike"],
                               oi=r.get("oi"), label=r.get("source")))
            for s in pivot_supports:
                db.add(SRLevel(timestamp=now, expiry_date=expiry, source="PIVOT_OI",
                               level_type="SUPPORT", strike=s["strike"],
                               oi=s.get("oi"), label=s.get("source")))
            for r in pivot_resistances:
                db.add(SRLevel(timestamp=now, expiry_date=expiry, source="PIVOT_OI",
                               level_type="RESISTANCE", strike=r["strike"],
                               oi=r.get("oi"), label=r.get("source")))
            db.commit()

            result["sr_levels"] = {
                "oi_fib": {
                    "supports": merged_supports,
                    "resistances": merged_resistances,
                },
                "pivot": {
                    "supports": pivot_supports,
                    "resistances": pivot_resistances,
                    "raw": pivot_data,
                },
                "fib_levels": fib_levels,
            }
        except Exception as e:
            print(f"[Scheduler] S/R fetch failed: {e}")

    return result


def _compute_user_positions(db: Session, user_id: int, market_data: dict) -> dict | None:
    """Compute live position data for a specific user."""
    from market_data import compute_risk_score, compute_hedge_v2, days_to_expiry

    chain_df = market_data.get("chain_df")
    spot = market_data.get("spot", 0)
    vix = market_data["snapshot"].get("india_vix", 0)
    vix_chg_pct = market_data["snapshot"].get("vix_change_pct", 0)
    expiry = market_data.get("expiry", "")
    dte = days_to_expiry(expiry) if expiry else 30

    if chain_df is None or chain_df.empty:
        return None

    open_trades = db.query(Trade).filter(
        Trade.user_id == user_id,
        Trade.status == TradeStatus.OPEN.value,
    ).all()

    if not open_trades:
        return None

    # Get S/R levels for hedge engine
    sr_levels = market_data.get("sr_levels")
    supports = []
    resistances = []
    if sr_levels and sr_levels.get("oi_fib"):
        supports = sr_levels["oi_fib"].get("supports", [])
        resistances = sr_levels["oi_fib"].get("resistances", [])

    positions = []
    ce_risk_scores = []
    pe_risk_scores = []
    hedge_suggestions = []

    for trade in open_trades:
        opt_type = "CE" if "CE" in trade.trade_type else "PE"
        match = chain_df[(chain_df["Strike"] == trade.strike) & (chain_df["Type"] == opt_type)]

        if match.empty:
            positions.append({
                "trade_id": trade.id,
                "trade_type": trade.trade_type,
                "strike": trade.strike,
                "current_ltp": None,
                "current_iv": None,
                "current_delta": None,
                "unrealized_pnl": None,
            })
            continue

        row = match.iloc[0]
        current_ltp = float(row["LTP"])
        current_iv = float(row["IV"])
        current_delta = float(row["delta"])
        current_gamma = float(row.get("gamma", 0))
        current_theta = float(row.get("theta", 0))

        if "SELL" in trade.trade_type:
            unrealized_pnl = round((trade.entry_premium - current_ltp) * LOT_SIZE * trade.quantity, 2)
        else:
            unrealized_pnl = round((current_ltp - trade.entry_premium) * LOT_SIZE * trade.quantity, 2)

        iv_change_pct = round(((current_iv - trade.entry_iv) / trade.entry_iv * 100)
                              if trade.entry_iv > 0 else 0, 1)

        risk = None
        hedge = None
        if trade.parent_trade_id is None:
            risk = compute_risk_score(
                delta=current_delta,
                entry_iv=trade.entry_iv,
                current_iv=current_iv,
                entry_premium=trade.entry_premium,
                current_ltp=current_ltp,
                current_spot=spot,
                strike=trade.strike,
                vix_abs=vix,
                gamma=current_gamma,
                theta=current_theta,
                dte=dte,
                vix_chg_pct=vix_chg_pct,
            )
            if "CE" in trade.trade_type:
                ce_risk_scores.append(risk["score"])
            else:
                pe_risk_scores.append(risk["score"])

            # Compute hedge suggestion when needed (only for SELL positions)
            if risk.get("hedge_required") and "SELL" in trade.trade_type:
                try:
                    hedge = compute_hedge_v2(
                        side=opt_type,
                        sold_strike=trade.strike,
                        entry_premium=trade.entry_premium,
                        current_spot=spot,
                        chain_df=chain_df,
                        dte=dte,
                        supports=supports,
                        resistances=resistances,
                    )
                    if hedge:
                        hedge_suggestions.append({
                            "trade_id": trade.id,
                            "trade_type": trade.trade_type,
                            "strike": trade.strike,
                            "hedge": hedge,
                        })
                except Exception as e:
                    print(f"[Scheduler] Hedge computation failed for trade {trade.id}: {e}")

        positions.append({
            "trade_id": trade.id,
            "trade_type": trade.trade_type,
            "strike": trade.strike,
            "expiry_date": trade.expiry_date,
            "entry_premium": trade.entry_premium,
            "entry_iv": trade.entry_iv,
            "entry_delta": trade.entry_delta,
            "quantity": trade.quantity,
            "current_ltp": current_ltp,
            "current_iv": current_iv,
            "current_delta": current_delta,
            "current_gamma": current_gamma,
            "current_theta": current_theta,
            "iv_change_pct": iv_change_pct,
            "unrealized_pnl": unrealized_pnl,
            "risk": risk,
            "hedge": hedge,
            "parent_trade_id": trade.parent_trade_id,
        })

    return {
        "positions": positions,
        "ce_risk": max(ce_risk_scores) if ce_risk_scores else None,
        "pe_risk": max(pe_risk_scores) if pe_risk_scores else None,
        "hedge_suggestions": hedge_suggestions,
        "spot": spot,
    }
